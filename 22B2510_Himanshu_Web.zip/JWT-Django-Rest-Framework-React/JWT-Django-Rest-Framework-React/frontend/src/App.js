
import React from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import PrivateRoute from './utils/PrivateRoute';
import Navbar from './views/Navbar';
import Homepage from './views/Homepage';
import Registerpage from './views/Registerpage';
import Loginpage from './views/Loginpage';

import FileUploadForm from './FileUploadForm';
import FileDisplayPage from './FileDisplayPage';
import FileDetailsPage from './FileDetailsPage';

function App() {
  return (
    <Router>
      <AuthProvider>
        <Navbar />
        <Switch>
          
          <Route component={Loginpage} path="/login" />
          <Route component={Registerpage} path="/register" exact />
          <Route component={Homepage} path="/" exact />
         
<Route component={FileUploadForm} path="/upload" />
          <Route component={FileDisplayPage} path="/files" />
          <Route component={FileDetailsPage} path="/detail" />
        
        </Switch>
      </AuthProvider>
    </Router>
  );
}

export default App;
