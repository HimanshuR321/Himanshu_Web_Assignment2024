// FileUploadForm.js

import React, { useState } from 'react';
import axios from 'axios';

const FileUploadForm = () => {
    const [title, setTitle] = useState('');
    const [file, setFile] = useState(null);
    const [password, setPassword] = useState('');

    const handleFileChange = (e) => {
        setFile(e.target.files[0]);
    };

    const handleSubmit = async (e) => {
        e.preventDefault();

        const formData = new FormData();
        formData.append('title', title);
        formData.append('file', file);
        formData.append('password', password);

        try {
            const response = await axios.post('http://127.0.0.1:8000/api/upload/', formData);
            console.log(response.data);
        } catch (error) {
            console.error(error);
        }
    };

    return (
        <form onSubmit={handleSubmit} style={{ maxWidth: '400px', margin: 'auto', marginTop: '30vh', backgroundColor: '#333', color: '#fff', padding: '20px', borderRadius: '5px' }}>
            <input
                type="text"
                placeholder="File Name"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                style={{ width: '100%', marginBottom: '10px', padding: '5px', backgroundColor: '#444', color: '#fff' }}
            />
            <input type="file" onChange={handleFileChange} style={{ marginBottom: '10px' }} />
            <input
                type="password"
                placeholder="File Password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                style={{ width: '100%', marginBottom: '10px', padding: '5px', backgroundColor: '#444', color: '#fff' }}
            />
            <button type="submit" style={{ width: '100%', padding: '10px', backgroundColor: '#007bff', color: '#fff', border: 'none' }}>
                Upload File
            </button>
        </form>
    );
};

export default FileUploadForm;
