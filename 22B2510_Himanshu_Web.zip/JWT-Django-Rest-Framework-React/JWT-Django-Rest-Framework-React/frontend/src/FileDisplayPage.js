// FileDisplayPage.js

import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { saveAs } from 'file-saver';

const FileDisplayPage = () => {
    const [files, setFiles] = useState([]);
    const [selectedFile, setSelectedFile] = useState(null);
    const [password, setPassword] = useState('');
    const [errorMessage, setErrorMessage] = useState('');

    useEffect(() => {
        fetchFiles();
    }, []);

    const fetchFiles = async () => {
        try {
            const response = await axios.get('http://127.0.0.1:8000/api/files/');
            setFiles(response.data);
        } catch (error) {
            console.error(error);
        }
    };

    const handleFileSelect = (file) => {
        setSelectedFile(file);
        setErrorMessage('');
    };

    const handlePasswordSubmit = async (e) => {
        e.preventDefault();

        try {
            const response = await axios.post(`http://127.0.0.1:8000/api/files/${selectedFile.id}/verify_password/`, { password });
            if (response.data.success) {
                // Password is correct, download the file
                downloadFile();
            } else {
                setErrorMessage('Incorrect password. Please try again.');
            }
        } catch (error) {
            console.error(error);
        }
    };

    const downloadFile = async () => {
        try {
            const response = await axios.get(`http://127.0.0.1:8000/api/files/${selectedFile.id}/download/`, {
                responseType: 'blob', // Set responseType to 'blob' for file download
            });
            saveAs(response.data, selectedFile.title); // Save the blob as a file with the given title
        } catch (error) {
            console.error(error);
        }
    };

    return (
        <div style={{ backgroundColor: '#fff', minHeight: '100vh', display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
            <div style={{ maxWidth: '800px', width: '100%', padding: '20px', backgroundColor: '#333', color: '#fff', borderRadius: '5px' }}>
                <h1 style={{ textAlign: 'center', marginBottom: '20px' }}>Uploaded Files</h1>
                <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
                    {files.map((file) => (
                        <div key={file.id} style={{ marginBottom: '10px' }}>
                            <span>{file.title}</span>
                            <button onClick={() => handleFileSelect(file)} style={{ marginLeft: '10px', backgroundColor: '#007bff', color: '#fff', border: 'none', padding: '5px 10px', cursor: 'pointer' }}>Open</button>
                        </div>
                    ))}
                </div>
                {selectedFile && (
                    <div style={{ marginTop: '20px', backgroundColor: '#444', padding: '20px', borderRadius: '5px' }}>
                        <h2 style={{ textAlign: 'center', color: '#fff' }}>Enter Password to Open {selectedFile.title}</h2>
                        <form onSubmit={handlePasswordSubmit} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
                            <input type="password" placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)} style={{ width: '300px', marginBottom: '10px', padding: '5px', backgroundColor: '#333', color: '#fff' }} />
                            <button type="submit" style={{ padding: '5px 10px', backgroundColor: '#007bff', color: '#fff', border: 'none' }}>Submit</button>
                        </form>
                        <p style={{ textAlign: 'center', color: 'red', marginTop: '10px' }}>{errorMessage}</p>
                    </div>
                )}
            </div>
        </div>
    );
};

export default FileDisplayPage;
