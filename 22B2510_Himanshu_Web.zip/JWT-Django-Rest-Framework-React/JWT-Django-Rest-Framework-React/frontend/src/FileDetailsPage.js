// FileDetailsPage.js

import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { saveAs } from 'file-saver';

const FileDetailsPage = ({ match }) => {
    const [fileDetails, setFileDetails] = useState(null);
    const [password, setPassword] = useState('');
    const [errorMessage, setErrorMessage] = useState('');

    useEffect(() => {
        fetchFileDetails();
    }, []);

    const fetchFileDetails = async () => {
        try {
            const response = await axios.get(`http://127.0.0.1:8000/api/files/${match.params.fileId}/`);
            setFileDetails(response.data);
        } catch (error) {
            console.error(error);
        }
    };

    const handlePasswordSubmit = async (e) => {
        e.preventDefault();

        try {
            const response = await axios.post(`http://127.0.0.1:8000/api/files/${match.params.fileId}/verify_password/`, { password });
            if (response.data.success) {
                // Password is correct, download the file
                downloadFile();
            } else {
                setErrorMessage('Incorrect password. Please try again.');
            }
        } catch (error) {
            console.error(error);
        }
    };

    const downloadFile = async () => {
        try {
            const response = await axios.get(`http://127.0.0.1:8000/api/files/${match.params.fileId}/download/`, {
                responseType: 'blob', // Set responseType to 'blob' for file download
            });
            saveAs(response.data, fileDetails.title); // Save the blob as a file with the given title
        } catch (error) {
            console.error(error);
        }
    };

    if (!fileDetails) {
        return <div>Loading...</div>;
    }

    return (
        <div style={{ backgroundColor: '#fff', maxWidth: '800px', margin: '20px auto', padding: '20px', borderRadius: '5px' }}>
            <h1 style={{ textAlign: 'center', marginBottom: '20px' }}>{fileDetails.title}</h1>
            <p style={{ textAlign: 'center' }}>Uploaded At: {fileDetails.uploaded_at}</p>
            <form onSubmit={handlePasswordSubmit} style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', marginTop: '20px' }}>
                <input type="password" placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)} style={{ marginRight: '10px', padding: '5px' }} />
                <button type="submit" style={{ padding: '5px 10px', backgroundColor: '#007bff', color: '#fff', border: 'none' }}>Submit</button>
            </form>
            {errorMessage && <p style={{ textAlign: 'center', color: 'red', marginTop: '10px' }}>{errorMessage}</p>}
        </div>
    );
};

export default FileDetailsPage;
