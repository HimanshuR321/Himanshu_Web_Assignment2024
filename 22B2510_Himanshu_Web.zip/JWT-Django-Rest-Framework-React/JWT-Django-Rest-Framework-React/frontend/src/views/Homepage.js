import React from 'react';
import './Homepage.css'; // Import your CSS file for styling

function Homepage() {
  return (
    <div className="homepage-container">
      {/* Background video */}
      <a href="#">
    <img src="image.png" alt="Company Logo" className="background-image" style={{opacity:'0.8', width:'100vw', height:'100vh'}} />
  </a>

      <main role="main">
        <div className="container content-container">
          {/* Main content */}
          <div className="jumbotron" style={{marginTop:'10vh'}}>
            <h1 className="display-3">Hello Core Team!</h1>
            <div className="card" >
              <div className="card-body">
                <p>
                  This platform is developed specifically for our E-Cell family to store important files and documents 
                </p>
                <p>
                  <a className="btn btn-primary btn-lg" href="#" role="button">
                    Explore »
                  </a>
                </p>
              </div>
            </div>
          </div>
          {/* Example row of columns */}
          <div className="row">
            <div className="col-md-4">
              <div className="card">
                <a href="">
                <div className="card-body">
                  <h2>Overall Coordinators</h2>
                  <p> They are the Overall Coordinators of E-Cell
                  </p>
                </div>
                </a>
                
              </div>
            </div>
            
            <div className="col-md-4">
              <div className="card">
                <a href="">
                  <div className="card-body">
                    <h2>Team Heads</h2>
                    <p> They are heads of particular portfolio
                    </p>
                  </div>
                </a>
              </div>
            </div>
            <div className="col-md-4">
              <div className="card">
                <a href="">
                  <div className="card-body">
                    <h2>Coordinators</h2>
                    <p> They coordinate with team heads during the entire tenure
                    </p>
                  </div>
                </a>
              </div>
            </div>
          </div>
          <hr />
        </div>
        
      </main>
     
    </div>
  );
}

export default Homepage;
