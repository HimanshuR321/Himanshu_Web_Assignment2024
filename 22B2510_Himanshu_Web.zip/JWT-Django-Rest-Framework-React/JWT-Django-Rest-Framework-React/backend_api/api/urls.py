from django.urls import path
from django.conf import settings
from django.conf.urls.static import static
from . import views
from rest_framework.routers import DefaultRouter
from rest_framework_simplejwt.views import (
    TokenRefreshView,
)

router = DefaultRouter()


urlpatterns = [
    path('token/', views.MyTokenObtainPairView.as_view(), name='token_obtain_pair'),
    path('token/refresh/', TokenRefreshView.as_view(), name='token_refresh'),
    path('register/', views.RegisterView.as_view(), name='auth_register'),
    path('test/', views.testEndPoint, name='test'),
    path('', views.getRoutes),
    
    path('upload/', views.upload_file, name='upload_file'),
    
    path('files/', views.get_files, name='get_files'),
    path('files/<int:file_id>/verify_password/', views.verify_password, name='verify_password'),
    path('files/<int:file_id>/', views.get_file_details, name='get_file_details'),
    path('files/<int:file_id>/download/', views.download_file, name='download_file'),


]

urlpatterns += router.urls

# Append static and media URL patterns for development
urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)