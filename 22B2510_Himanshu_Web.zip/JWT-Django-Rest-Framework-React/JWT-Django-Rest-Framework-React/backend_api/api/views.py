import os
from django.conf import settings
from django.shortcuts import get_object_or_404, render
from django.http import Http404, HttpResponse, JsonResponse
from api.models import User
from rest_framework import viewsets

from api.serializer import MyTokenObtainPairSerializer, RegisterSerializer, UploadedFileSerializer 
from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework_simplejwt.views import TokenObtainPairView
from rest_framework import generics
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework import status
from rest_framework.decorators import api_view, permission_classes
from rest_framework import viewsets

class MyTokenObtainPairView(TokenObtainPairView):
    serializer_class = MyTokenObtainPairSerializer

class RegisterView(generics.CreateAPIView):
    queryset = User.objects.all()
    permission_classes = (AllowAny,)
    serializer_class = RegisterSerializer


# Get All Routes

@api_view(['GET'])
def getRoutes(request):
    routes = [
        '/api/token/',
        '/api/register/',
        '/api/token/refresh/'
    ]
    return Response(routes)


@api_view(['GET', 'POST'])
@permission_classes([IsAuthenticated])
def testEndPoint(request):
    if request.method == 'GET':
        data = f"Congratulation {request.user}, your API just responded to GET request"
        return Response({'response': data}, status=status.HTTP_200_OK)
    elif request.method == 'POST':
        text = "Hello buddy"
        data = f'Congratulation your API just responded to POST request with text: {text}'
        return Response({'response': data}, status=status.HTTP_200_OK)
    return Response({}, status.HTTP_400_BAD_REQUEST)




from .models import UploadedFile


@api_view(['POST'])
def upload_file(request):
    serializer = UploadedFileSerializer(data=request.data)
    if serializer.is_valid():
        serializer.save()
        return Response(serializer.data, status=status.HTTP_201_CREATED)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


@api_view(['GET'])
def get_files(request):
    files = UploadedFile.objects.all()
    serializer = UploadedFileSerializer(files, many=True)
    return Response(serializer.data)

@api_view(['POST'])
def verify_password(request, file_id):
    try:
        file_obj = UploadedFile.objects.get(pk=file_id)
        password = request.data.get('password')
        if file_obj.password == password:
            return Response({'success': True})
        else:
            return Response({'success': False})
    except UploadedFile.DoesNotExist:
        return Response(status=status.HTTP_404_NOT_FOUND)
    

@api_view(['GET'])
def get_file_details(request, file_id):
    file_obj = get_object_or_404(UploadedFile, pk=file_id)
    serializer = UploadedFileSerializer(file_obj)
    return Response(serializer.data)

@api_view(['GET'])
def download_file(request, file_id):
    file_obj = get_object_or_404(UploadedFile, pk=file_id)
    file_path = os.path.join(settings.MEDIA_ROOT, str(file_obj.file))
    if os.path.exists(file_path):
        with open(file_path, 'rb') as fh:
            response = HttpResponse(fh.read(), content_type='application/pdf')
            response['Content-Disposition'] = 'inline; filename=' + os.path.basename(file_path)
            return response
    raise Http404    